package com.example.teambox_sk1;

import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;

import androidx.activity.*;
import androidx.appcompat.app.*;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "DomainDebug"; // 設定 Logcat 過濾標籤

    private Spinner spDomain, spIdentity;
    private TextView registMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        spDomain = findViewById(R.id.domainList);
        spIdentity = findViewById(R.id.identityList);
        registMsg = findViewById(R.id.registMsg);

        // 載入 Domain 選單
        ArrayAdapter<CharSequence> domainAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.domain_array,
                android.R.layout.simple_spinner_item
        );
        domainAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDomain.setAdapter(domainAdapter);

        // --- Domain Spinner 監聽器 ---
        spDomain.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedDomain = parent.getItemAtPosition(position).toString();
                Log.d(TAG, "Domain Changed -> From: " + position + ", To: " + selectedDomain);
                // detect the changes of Domain Spinner
                if (selectedDomain.equalsIgnoreCase("Education")) {
                    ArrayAdapter<CharSequence> identityAdapter = ArrayAdapter.createFromResource(
                            MainActivity.this,
                            R.array.identity_array,
                            android.R.layout.simple_spinner_item
                    );
                    identityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spIdentity.setAdapter(identityAdapter);
                    Log.d(TAG, "Identity Adapter loaded (Education)");
                } else if (selectedDomain.equalsIgnoreCase("Administrative")) {
                    spIdentity.setAdapter(null);
                    Log.d(TAG, "Identity Adapter clear (Administrative)");
                } else {
                    spIdentity.setAdapter(null);
                    Log.d(TAG, "Identity Adapter clear (other Domain)");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {Log.d(TAG, "Domain hav not selected");}
        });

        // --- Identity Spinner 監聽器 ---
        spIdentity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // detect the changes of Identity Spinner
                if (parent.getItemAtPosition(position) != null) {
                    String selectedIdentity = parent.getItemAtPosition(position).toString();
                    Log.d(TAG, "Identity Changed -> From: " + position + ", To: " + selectedIdentity);
                } else {
                    Log.d(TAG, "Identity is currently set null (null)");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d(TAG, "Identity have not selected");
            }
        });
    }
}
